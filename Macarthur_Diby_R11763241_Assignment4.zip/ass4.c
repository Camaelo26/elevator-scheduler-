/** C program that reads signed integer data from a file, makes decisions upon
each integer in the file, and then writes each integer to one or more files.This
program using multithreading and mutex locks or semaphores to ensure that the
various threads don’t interfere with one another.**/

#include <math.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
// define a buffer size
#define BUFFER_SIZE 10000

int buffer[BUFFER_SIZE]; // the shared buffer between everything
int buffer_pos_1 = 0;    // current position in the buffer for write
int buffer_pos2 = 0;     // current position in the buffer for read


pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER; // mutex that protect the buffer
pthread_cond_t cv_read = PTHREAD_COND_INITIALIZER; // condition variable for reader
pthread_cond_t cv_process = PTHREAD_COND_INITIALIZER; // condition variable for process



/** Function**/
void *read(void *arg);
void *process(void *arg);
void writer(int num);

/**Checks if a number is even.**/
int num_even(int num) {
  int numeven = num % 2 == 0;
  return numeven;
}

/** if a number is not even it is odd . **/
int num_odd(int num) {
  int numodd = !num_even(num);
  return numodd;
  ;
}

/**Verifies if a number is positive. **/
int num_positive(int num) {
  int numpositive = num > 0;
  return numpositive;
}

/**Verifies if a number is negative.**/
int num_negative(int num) {
  int numnegative = num < 0;
  return numnegative;
}

/**Checks if a number is a perfect square. **/
int num_square(int num) {
  if (num >= 0) { // a number has to be positive or equal to 0 to be a perfect square
    long long sr = sqrt(num);
    int numsquare = (sr * sr == num); // Store the result of the square check
    return numsquare;
  }
  return 0; // for negative num return 0 since they are not part of it
}

/** Check if a number is a perfect cube. **/
int num_cube(int num) {
  int numcube;
  if (num < 0) { // for neg numbers
    int cube_root = (int)round(pow(-num, 1.0 / 3.0));
    numcube = (num == -cube_root * cube_root * cube_root);
  } else { // for pos numbers.
    int cube_root = (int)round(pow(num, 1.0 / 3.0));
    numcube = (num == cube_root * cube_root * cube_root);
  }
  return numcube;
}
FILE *Even, *Odd, *Positive, *negative, *square, *Cube; // every files that will be created
/**writer function that write numbers to correspoding files regarding their
 * group**/
void writer(int num) {
    // Check if num is a square number
    if (num_square(num)) {
        fprintf(square, "%d\n", num);
    }

    // Check if num is a cube number
    if (num_cube(num)) {
        fprintf(Cube, "%d\n", num);
    }

    // Check if num is even
    if (num_even(num)) {
        fprintf(Even, "%d\n", num);
    }

    // Check if num is odd
    if (num_odd(num)) {
        fprintf(Odd, "%d\n", num);
    }

    // Check if num is positive
    if (num_positive(num)) {
        fprintf(Positive, "%d\n", num);
    }

    // Check if num is negative
    if (num_negative(num)) {
        fprintf(negative, "%d\n", num);
    }
}
bool end = false;        // variable for ebnd of file
/** function read that reads data from the file and puts it into a buffer**/
void *read(void *arg) {
  // open the file
  FILE *file = fopen((char *)arg, "r");
  // reading the file  before the file ends
  while (!feof(file)) {
    pthread_mutex_lock(&mtx); // acquire lock on the buffer
    int bufferfl= (buffer_pos_1 + 1) % BUFFER_SIZE;
    // if the buffer is full, wait for the process to finish
    while (bufferfl == buffer_pos2) {
      pthread_cond_wait(&cv_read, &mtx);
    }
    // read a number from the file and put it in the buffer till the end of the
    // readed file
    int res_resul;
    res_resul = fscanf(file, "%d", &buffer[buffer_pos_1]);
    
    if (res_resul!= 1) {
      end = true;
      pthread_cond_broadcast(&cv_process); // unblock all threads currently waiting on cvprocess
      pthread_mutex_unlock(&mtx); // unlock the mutex
      break;
    }
    // update the buffer position for write
    buffer_pos_1 = (buffer_pos_1 + 1) % BUFFER_SIZE;
    pthread_cond_signal(&cv_process); // ignal the process
    pthread_mutex_unlock(&mtx);       // unlock the mutex
  }

  fclose(file);
  return NULL;
}

/** function process that reads data from the buffer and write it to the
 * files**/
void *process(void *arg) {
  // open all the files that be needed to be written to
  negative = fopen("negative.out", "w");
  Even = fopen("even.out", "w");
  Odd = fopen("odd.out", "w");
  Cube = fopen("cube.out", "w");
  Positive = fopen("positive.out", "w");
  square = fopen("square.out", "w");
  

  while (true) {
    pthread_mutex_lock(&mtx); // acquire lock on the buffer
    //  when the buffer is empty and the 'end' flag is true wait
    while (!end && buffer_pos2 == buffer_pos_1) {
      pthread_cond_wait(&cv_process, &mtx);
    }
    // If the 'end' flag is false and the buffer is empty, break the loop
    if (end && buffer_pos2 == buffer_pos_1) {
      pthread_mutex_unlock(&mtx);
      break;
    }

    // read a number from the buffer and process it
    int num = buffer[buffer_pos2];
    // update the buffer position for read
    buffer_pos2 = (buffer_pos2 + 1) % BUFFER_SIZE;
    pthread_cond_signal(&cv_read); // signal the reader
    pthread_mutex_unlock(&mtx);    // unlock the mutex

    writer(num); // write the numebr to the file
  }

  // close all files
  fclose(Even);
  fclose(Odd);
  fclose(Positive);
  fclose(negative);
  fclose(square);
  fclose(Cube);

  return NULL;
}

int main(int argc, char *argv[]) {
//an appropriate error message if the argument is not provided or the file does not exist
    FILE *file = fopen(argv[1], "r");
  if (file == NULL) {
    printf("Error opening file");
    return 1;
  }
    
  printf("Macarthur Diby \n");
  printf("R11763241 \n");
  pthread_t reading, processing; // set 2 pthread for read and process
  pthread_create(&reading, NULL, read, argv[1]);    // create thread for reading
  pthread_create(&processing, NULL, process, NULL); // crate thread to process
  pthread_join(reading, NULL);                      // reading till it stop
  pthread_join(processing, NULL);                   // processing till it stops
  return 0;
}
